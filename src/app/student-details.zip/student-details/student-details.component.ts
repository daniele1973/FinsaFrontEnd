import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentService } from '../student/student.service';
import { Subscription } from 'rxjs';
import { Student } from '../student/student';
@Component({
  selector: 'app-student-details',
  templateUrl: './student-details.component.html',
  styleUrls: ['./student-details.component.css']
})
export class StudentDetailsComponent implements OnInit {
  private sub :Subscription;
  student :Student;
  errorMessage: "";

  constructor(private route :ActivatedRoute,
              private router :Router,
              private studentService :StudentService) {} 

  ngOnInit() {
    this.sub = this.route.params.subscribe(
      params => {
        const id = +params['id'];
        this.getStudent(id);
      }
    )
  }
  getStudent(id: number): any {
    console.log(`Chiamata  getStudent(${id})`);

    this.studentService.getStudent(id).subscribe(
      stud => this.student=stud
    )
  }

}
